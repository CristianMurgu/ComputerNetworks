#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <string.h>
#define MSG1 "error"
#include <sys/socket.h>
#include <utmp.h>
#include <time.h>
//#define port 2003
int main(int argc, char* argv[])
{
	pid_t child;
	int socket[2];
	char aux[3];
	char solution[1024];
	int logged=0;
	int file_r_fifo, file_w_fifo;
	char *myfifo= "/tmp/fifo_tema11";
	char *myfifo_w= "/tmp/fifo_tema12";
	char task[64];
	mkfifo(myfifo, 0666);
	mkfifo(myfifo_w, 0666);
	int pipe_child[2];
	while(1)
	{
		file_r_fifo=open(myfifo,O_RDONLY);
		read(file_r_fifo, task, 64);
		close(file_r_fifo);
		if(strstr(task,"login")) //login
		{
			printf("%s\n", "Server login requested");
			pipe(pipe_child);
			child=fork();
			if(child==0)
			{
				char user_searched[64], user_found[64];
				bool solved=0;
				strcpy(user_searched, task+8);
				FILE* file_r_db;
				close(pipe_child[0]);
				file_r_db=fopen("database.txt","r");
				while(fscanf(file_r_db, "%s", user_found)!=EOF)//fgets(user_found, 64, file_r_db))
				{
					if(strstr(user_searched, user_found))
					{
						strcpy(aux, "16");
						write(pipe_child[1], aux, 2);
						write(pipe_child[1], "login successful\0", 17);
						solved=1;
						close(pipe_child[1]);
						break;
					}
				}
				fclose(file_r_db);
				if(solved==0)
				{
					strcpy(aux, "18");
					write(pipe_child[1], aux, 2);
					write(pipe_child[1], "login unsuccessful\0", 19);
					solved=1;
					close(pipe_child[1]);
				}
			}
			else if(child)
			{
				wait(NULL);
				read(pipe_child[0], solution, sizeof(solution));
				close(pipe_child[0]);
				close(pipe_child[1]);
				file_w_fifo=open(myfifo_w, O_WRONLY);
				write(file_w_fifo, &solution, sizeof(solution));
				close(file_w_fifo);
				if(!strstr(solution, "unsuccessful"))
					logged++;
			}	
		}//login
		else if(strstr(task, "logout"))//logout
		{
			if(socketpair(AF_UNIX, SOCK_STREAM, 0, socket)==-1)
			{
				fprintf(stderr, "%s\n", MSG1);
				exit(2);
			}
			printf("%s\n", "Server logout requested");
			if(logged)
			{
				strcpy(aux,"1");
				write(socket[1],aux,1);
			}
			else
			{
				strcpy(aux,"0");
				write(socket[1], aux,1);
			}
			child=fork();
			if(child==0)
			{
				close(socket[1]);
				char check[2];
				read(socket[0], check, 1);
				if(check[0]=='1')
				{
					strcpy(aux,"17");
					write(socket[0], aux, 2);
					write(socket[0], "logout successful\0", 18);
				}
				else if(check[0]=='0')
				{
					strcpy(aux,"19");
					write(socket[0], aux, 2);
					write(socket[0], "logout unsuccessful\0", 20);
				}
				close(socket[0]);
			}
			else if(child)
			{
				close(socket[0]);
				wait(NULL);
				if(logged!=0)
					logged--;
				read(socket[1], solution, sizeof(solution));
				close(socket[1]);
				file_w_fifo=open(myfifo_w, O_WRONLY);
				write(file_w_fifo, &solution, sizeof(solution));
				close(file_w_fifo);
			}
		}//logout
		else if(strstr(task, "quit"))//quit
		{
			printf( "%s\n", "Server said: Bruh");
			pipe(pipe_child);
			child=fork();
			if(child==0)
			{
				close(pipe_child[0]);
				strcpy(aux, "11");
				write(pipe_child[1], aux, 2);
				write(pipe_child[1], "server left\0", 12);
				close(pipe_child[1]);
			}
			else if(child)
			{
				close(pipe_child[1]);
				read(pipe_child[0], solution, sizeof(solution));
				close(pipe_child[0]);
				file_w_fifo=open(myfifo_w, O_WRONLY);
				write(file_w_fifo, &solution, sizeof(solution));
				close(file_w_fifo);
				kill(getpid(),SIGKILL);
			}
		}//quit
		else if(strstr(task, "get-proc-info"))//get-proc-info
		{
			printf("%s\n", "Server get-proc-info requested");
			if(socketpair(AF_UNIX, SOCK_STREAM, 0, socket)==-1)
			{
				fprintf(stderr, "%s\n", MSG1);
				exit(2);
			}
			child=fork();
			if(child==0)
			{
				close(socket[1]);
				char file_searched[64], text[128], result[256];
				strcpy(result, "");
				strcpy(file_searched, "/proc/");
				strcat(file_searched, task+16);
				strcat(file_searched, "/status");
				FILE *fr;
				fr=fopen(file_searched, "r");
				if(fr==NULL)
				{
					strcpy(result, "The pid doesn't exist\0");
				}
				else
				{
					while(fgets(text, sizeof(text), fr))
					{
						if(strstr(text, "Name") || strstr(text, "State") || strstr(text, "PPid") || strstr(text, "Uid") || strstr(text, "VmSize"))
						{
							strcat(result, text);
						}
					}
					fclose(fr);
				}
				int len=strlen(result);
				sprintf(aux , "%d", len);
				if(logged)
				{
					write(socket[0], aux, sizeof(aux)-1);
					write(socket[0], result, sizeof(result));
				}
				else
				{
					write(socket[0], "10", 2);
					write(socket[0], "not logged\0", 11);
				}
				close(socket[0]);
			}
			else if(child)
			{
				wait(NULL);
				close(socket[0]);
				read(socket[1], solution, sizeof(solution));
				close(socket[1]);
				file_w_fifo=open(myfifo_w, O_WRONLY);
				write(file_w_fifo, &solution, sizeof(solution));
				close(file_w_fifo);
			}
		}//get-proc-info
		else if(strstr(task, "get-logged-users"))
		{
			printf("%s\n", "Server get-logged-users requested");
			pipe(pipe_child);
			child=fork();
			if(child==0)
			{
				close(pipe_child[0]);
				char result[256], date[32], result_aux[128];
				struct utmp *info;
				setutent();
				info=getutent();
				strcpy(result, "");
				while(info)
				{
					if(info->ut_type==USER_PROCESS) 
					{
						strncpy(result_aux, info->ut_user, 32);//, (int)(sizeof info->ut_id));
						strcat(result, result_aux);
						strcat(result, "\n");
						strncpy(result_aux, info->ut_host, 32);//, (int)(sizeof info->ut_host));
						strcat(result, result_aux);
						strcat(result, "\n");
						sprintf(date, "%d", info->ut_time);
						strcat(result, date);
					}
					info=getutent();
				}
				if(logged)
				{
					int len=strlen(result);
					sprintf(aux , "%d", len);
					write(pipe_child[1], aux, sizeof(aux)-1);
					write(pipe_child[1], result, sizeof(result));
				}
				else
				{
					write(pipe_child[1], "10", 2);
					write(pipe_child[1], "not logged\0", 11);
				}
				close(pipe_child[1]);
			}
			else if(child)
			{
				wait(NULL);
				close(pipe_child[1]);
				read(pipe_child[0], solution, sizeof(solution));
				close(pipe_child[0]);
				file_w_fifo=open(myfifo_w, O_WRONLY);
				write(file_w_fifo, &solution, sizeof(solution));
				close(file_w_fifo);
			}
		}
		else if(child)
		{
			printf("%s\n", "Server got an unknown command");
			file_w_fifo=open(myfifo_w, O_WRONLY);
			write(file_w_fifo, "36Unknown command I'm just a server...\0", 39);
			close(file_w_fifo);
		}
		if(child==0)
		break;
	}
	return 0;
}