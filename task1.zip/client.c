#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <string.h>
#define MSG1 "error"
#include <sys/socket.h>
#define port 2003
int main(int argc, char* argv[])
{
	char str[1024];
	int file_w, file_r;
	//int code_length;
	char *myfifo= "/tmp/fifo_tema11";
	char *myfifo_r= "/tmp/fifo_tema12";
	mkfifo(myfifo, 0666);
	mkfifo(myfifo_r, 0666);
	while(scanf("%[^\n]%*c", str))
	{
		file_w= open(myfifo, O_WRONLY);
		if(file_w==-1)
		{
			fprintf(stderr, "%s\n", MSG1);
			exit(2);
		}
		write(file_w, str, strlen(str)+1);
		close(file_w);
		strcpy(str, "");
		file_r= open(myfifo_r, O_RDONLY);
		if(file_r==-1)
		{
			fprintf(stderr, "%s\n", MSG1);
			exit(2);
		}
		read(file_r, str, sizeof(str));
		//read(file_r, str, code_length+1);
		printf("%s\n\n", str);
		close(file_r);
	}
	exit(0);
}